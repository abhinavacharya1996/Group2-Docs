﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE.Exception
{
    public class PolicyException : ApplicationException
    {
        public PolicyException() : base()
        { }

        public PolicyException(string Message) : base(Message)
        { }
    }
}
