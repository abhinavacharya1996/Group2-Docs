﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PE.Entity;

namespace PE.PL
{
    /// <summary>
    /// Interaction logic for CustomerPolicyDetails.xaml
    /// </summary>
    public partial class CustomerPolicyDetails : Window
    {
        public CustomerPolicyDetails()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cbPremiumPaymentFrequency.Items.Add("Monthly");
            cbPremiumPaymentFrequency.Items.Add("Quarterly");
            cbPremiumPaymentFrequency.Items.Add("Half-Yearly");
            cbPremiumPaymentFrequency.Items.Add("Annualy");
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
           
            EndorsementsTemp newEsm = new EndorsementsTemp();
            newEsm.transactionID = Convert.ToInt32(txtTransactionID.Text);
            newEsm.policyNumber = Convert.ToInt32(txtPolicyNumber.Text);
            newEsm.policyName = txtPolicyName.Text;
            newEsm.productLine = txtProductLine.Text;
            newEsm.customerName = txtInsuredName.Text;
            newEsm.customerDOB = Convert.ToDateTime(txtDOB.Text);
            if (rbFemale.IsChecked == true)
                newEsm.customerGender = rbFemale.Content.ToString();
            else if(rbMale.IsChecked== true)
                newEsm.customerGender = rbMale.Content.ToString();
            newEsm.nomineeName = txtNomineeName.Text;
            newEsm.nomineeRelation = txtNomineeRelation.Text;
            if (rbNonSmoker.IsChecked == true)
                newEsm.customerSmoking = rbNonSmoker.Content.ToString();
            else if (rbSmoker.IsChecked == true)
                newEsm.customerSmoking = rbSmoker.Content.ToString();
           newEsm.customerAddress = txtAddress.Text;
            newEsm.customerTelephone = txtTelephone.Text;                      
            newEsm.premiumFrequency = cbPremiumPaymentFrequency.SelectedValue.ToString();   
                        
            }
        }
    }
