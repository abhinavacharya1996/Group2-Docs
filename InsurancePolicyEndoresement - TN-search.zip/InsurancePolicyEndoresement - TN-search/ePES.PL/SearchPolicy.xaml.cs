﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;



namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for SearchPolicy.xaml
    /// </summary>
    public partial class SearchPolicy : Window
    {
        public SearchPolicy()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtCustomerID.Clear();
            txtCustomerName.Clear();
            txtDOB.Clear();
            //dtpicker.ClearValue();
            txtPolicyNumber.Clear();
            //dgPolicy.ClearValue(;  // clear data grid 
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PolicyValidations bllObj = new PolicyValidations();
                int custID_t = Convert.ToInt32(txtCustomerID.Text);
                DateTime DOB_t = Convert.ToDateTime(txtDOB.Text);
                int PN_t = Convert.ToInt32(txtPolicyNumber.Text);
                string Name_t = txtCustomerName.Text;
                DataTable dtEmp = bllObj.GetPolicy_BLL(custID_t, DOB_t, PN_t, Name_t);

                dgPolicy.ItemsSource = dtEmp.DefaultView;


            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (PolicyExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
