﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using ePES.Entity;          //Reference to PolicyEndorsement System Entity
using ePES.Exceptions;     //Reference to PolicyEndorsement System Exception
using ePES.DAL;             //Reference to PolicyEndorsement System Data Access Layer 


namespace ePES.BL
{
    /// <summary>
    /// Insured Name : Developer Insured Name
    /// Insured Age : Developer Insured Age
    /// Description : This class will have business logic for PolicyEndorsement
    /// Date of Modification : 26th Oct 2018
    /// </summary>
    public class PolicyValidations
    {
        //Method to validate policy details
        public static bool ValidateEndorsementsTemp(EndorsementsTemp temp)
        {
            bool isValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                //Checking Customer name
                if (temp.customerName == string.Empty)
                {
                    message.Append("Customer Name should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(temp.customerName, "[A-Z][a-z]{1,}"))
                {
                    message.Append("Customer Name should start with Capital Alphabet\n");
                    isValidated = false;
                }

                //Checking Customer Date Of Birth
                if (temp.customerDOB > DateTime.Now)
                {
                    message.Append("Date Of Birth should be less than or equal to Today's date\n");
                    isValidated = false;
                }

                //Checking Customer Gender
                //if(temp.customerGender == )
                

                //Checking Nominee Name
                if (temp.nomineeName == string.Empty)
                {
                    message.Append("Nominee Name should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(temp.nomineeName, "[A-Z][a-z]"))
                {
                    message.Append("Nominee Name should start with Capital Alphabet\n");
                    isValidated = false;
                }

                //Checking Nominee Relation
                if (temp.nomineeRelation == string.Empty)
                {
                    message.Append("Nominee Relation should be provided\n");
                    isValidated = false;
                }

                ////Checking if Customer is Smoker or Non-Smoker
                //if (temp.customerSmoking.ToLower() != "Smoker" && temp.customerSmoking.ToLower() != "Non-Smoker")
                //{
                //    message.Append("Customer should be either Smoker or Non-Smoker\n");
                //    isValidated = false;
                //}

                //Checking Customer Address
                if (temp.customerAddress == string.Empty)
                {
                    message.Append("Customer Address should be provided\n");
                    isValidated = false;
                }

                //Checking Telephone Number
                if (!Regex.IsMatch(temp.customerTelephone, "[7-9][0-9]{9}"))
                {
                    message.Append("Telephone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    isValidated = false;
                }

                //Checking Premiun Payment Frequency
                //if (temp.premiumFrequency.ToUpper() != "Monthly" && temp.premiumFrequency.ToLower() != "Quaterly" && temp.premiumFrequency.ToLower() != "Half Yearly" && temp.premiumFrequency.ToLower() != "Annually")
                //{
                //    message.Append("Premium  Frequency should be either Monthly or Quaterly or Half Yearly or Annually\n");
                //    isValidated = false;
                //}

                if (isValidated == false)
                    throw new PolicyExceptions(message.ToString());
            }
            catch (PolicyExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isValidated;
        }
    }
}