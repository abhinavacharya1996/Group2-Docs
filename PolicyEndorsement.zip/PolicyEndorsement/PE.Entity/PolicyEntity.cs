﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE.Entity
{
    public partial class EndorsementsTemp
    {
        public int transactionID { get; set; }
        public int customerID { get; set; }
        public int policyNumber { get; set; }
        public string policyName { get; set; }
        public string productLine { get; set; }
        public string customerName { get; set; }
        public string customerAddress { get; set; }
        public string customerTelephone { get; set; }
        public string customerGender { get; set; }
        public Nullable<System.DateTime> customerDOB { get; set; }
        public string customerSmoking { get; set; }
        public string nomineeName { get; set; }
        public string nomineeRelation { get; set; }
        public string premiumFrequency { get; set; }
    }
    public partial class LoginCredential
    {
        public string loginID { get; set; }
        public string userpassword { get; set; }
        public string userType { get; set; }
    }

    public partial class Endorsements
    {
        public int transactionID { get; set; }
        public int customerID { get; set; }
        public int policyNumber { get; set; }
        public string policyName { get; set; }
        public string productLine { get; set; }
        public string customerName { get; set; }
        public string customerAddress { get; set; }
        public string customerTelephone { get; set; }
        public string customerGender { get; set; }
        public Nullable<System.DateTime> customerDOB { get; set; }
        public string customerSmoking { get; set; }
        public string nomineeName { get; set; }
        public string nomineeRelation { get; set; }
        public string premiumFrequency { get; set; }
    }
    //public class PolicyEntity
    //{
    //}
}
