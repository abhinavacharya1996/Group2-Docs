﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ePES.Exceptions
{
    public class PolicyExceptions : ApplicationException
    {
        //Default Constructor
        public PolicyExceptions() : base()
        { }

        //Parameterized constructor with message parameter
        public PolicyExceptions(string message) : base(message)
        { }
    }
}

